POLLEN ROBOTICS RPI ROBOT HAT - QUOTATION INPUTS
Upstream revision: 23eab11927f95ceca0dfa35bf182caeb7db39ea0
Official production files copied unchanged. See LICENSE.
PCB: 4 layers, 1.0 mm, approximately 65.0 x 30.9 mm.
Request one completed board; quote board/panel minimums separately.
The nested PCB ZIP is the Gerber/drill upload. BOM and POS are assembly inputs.
Have the service review BOM mapping, rotation, both sides, DNP rows, fiducials, logos and through-hole work.
Do not treat every position row as a fitted electronic component.
Do not populate DNP components or accept substitutions without review.
This board does not supply tested ID-200 IMU bridge firmware or a battery charger.
The robot power distribution and servo voltage still need engineering review.
No fabrication quote or order has been submitted by this project.
