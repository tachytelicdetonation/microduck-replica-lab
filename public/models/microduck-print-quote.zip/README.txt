MICRODUCK PRINT QUOTATION / FIT REFERENCE
Not released or physically validated manufacturing CAD.
30 STL types; 36 modeled pieces.
STL units: MILLIMETRES. Do not rescale or print as an assembly.
Set copies from print-order.csv: uploading each STL once is not the full quantity.
Materials are proposals. Get a manufacturability review and small fit batch first.
review-before-order/ files require a component decision before ordering.
The fit-check subset is included in the full set; do not order it twice by accident.
See PRINT_SERVICE_BRIEF.md. Excludes servos, bearings, boards, battery, lens and speaker.
Source: pollen-robotics/microduck_rl @ 2b25a48b08f1f17bc38c90bb03144c81fbd9ed07
Geometry: Pollen Robotics, CC BY-NC-SA 4.0. Attribution included.
